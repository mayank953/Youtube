print("Hello World")

inp = input("how are you")

print("Bye World")